-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: manpower_erp_new
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `normal_balance` enum('debit','credit') NOT NULL DEFAULT 'debit',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_types_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES (1,'Assets','debit','2026-11-20 10:15:16','2026-11-20 10:15:16'),(2,'Liabilities','credit','2026-11-20 10:15:16','2026-11-20 10:15:16'),(3,'Equity','credit','2026-11-20 10:15:16','2026-11-20 10:15:16'),(4,'Income','credit','2026-11-20 10:15:16','2026-11-20 10:15:16'),(5,'Expenses','debit','2026-11-20 10:15:16','2026-11-20 10:15:16');
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `account_type_id` bigint(20) unsigned NOT NULL,
  `normal_balance` enum('debit','credit') NOT NULL DEFAULT 'debit',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_code_unique` (`code`),
  KEY `accounts_created_by_foreign` (`created_by`),
  KEY `accounts_updated_by_foreign` (`updated_by`),
  KEY `accounts_status_index` (`status`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  KEY `accounts_parent_id_index` (`parent_id`),
  CONSTRAINT `accounts_account_type_id_foreign` FOREIGN KEY (`account_type_id`) REFERENCES `account_types` (`id`),
  CONSTRAINT `accounts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `accounts_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `accounts_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'1000','Assets',NULL,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(2,'1100','Cash & Bank',1,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(3,'1110','Cash in Hand',2,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(4,'1120','Bank — Main Account',2,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(5,'1200','Accounts Receivable',1,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(6,'1210','Agent Receivable',5,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(7,'1220','Candidate Receivable',5,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(8,'1300','Advances',1,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(9,'1310','Advance to Employee',8,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(10,'1320','Advance to Vendor',8,1,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(11,'2000','Liabilities',NULL,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(12,'2100','Accounts Payable',11,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(13,'2110','Vendor Payable',12,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(14,'2120','Salary Payable',12,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(15,'2130','Deductions Payable',12,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(16,'2200','Agent Payable',11,2,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(17,'3000','Equity',NULL,3,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(18,'3100','Owner\'s Equity',17,3,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(19,'3200','Retained Earnings',17,3,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(20,'4000','Income',NULL,4,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(21,'4100','Service Charge Income',20,4,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(22,'4200','Agent Charge Income',20,4,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(23,'4300','Other Income',20,4,'credit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(24,'5000','Expenses',NULL,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(25,'5100','Salary Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(26,'5200','Office Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(27,'5300','Medical Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(28,'5400','Visa Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(29,'5500','Training Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(30,'5600','Travel Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(31,'5700','Bank Charges',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL),(32,'5800','Refund Expense',24,5,'debit','active',NULL,NULL,NULL,'2026-11-20 10:15:17','2026-11-20 10:15:17',NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_country`
--

DROP TABLE IF EXISTS `agent_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_country` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) unsigned NOT NULL,
  `country_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_country_agent_id_index` (`agent_id`),
  KEY `agent_country_country_id_index` (`country_id`),
  CONSTRAINT `agent_country_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_country_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_country`
--

LOCK TABLES `agent_country` WRITE;
/*!40000 ALTER TABLE `agent_country` DISABLE KEYS */;
INSERT INTO `agent_country` VALUES (1,1,6,NULL,NULL),(2,1,18,NULL,NULL),(3,1,14,NULL,NULL),(4,1,12,NULL,NULL),(5,1,15,NULL,NULL),(6,1,20,NULL,NULL),(7,1,16,NULL,NULL),(8,1,17,NULL,NULL);
/*!40000 ALTER TABLE `agent_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_documents`
--

DROP TABLE IF EXISTS `agent_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `agent_documents_created_by_foreign` (`created_by`),
  KEY `agent_documents_updated_by_foreign` (`updated_by`),
  KEY `agent_documents_agent_id_index` (`agent_id`),
  KEY `agent_documents_type_index` (`type`),
  CONSTRAINT `agent_documents_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_documents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agent_documents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agent_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_documents`
--

LOCK TABLES `agent_documents` WRITE;
/*!40000 ALTER TABLE `agent_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `nid` varchar(255) DEFAULT NULL,
  `trade_license` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agents_created_by_foreign` (`created_by`),
  KEY `agents_updated_by_foreign` (`updated_by`),
  KEY `agents_status_index` (`status`),
  KEY `agents_branch_id_index` (`branch_id`),
  KEY `agents_user_id_index` (`user_id`),
  CONSTRAINT `agents_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` VALUES (1,2,'New agent test','01912549957','razibhasan2403@gmail.com','Mymensingh\r\nNetrakona Sadar',NULL,'00200','active',1,1,1,'2026-11-20 10:31:44','2026-11-20 10:31:44',NULL);
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `airlines`
--

DROP TABLE IF EXISTS `airlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airlines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `airlines_code_unique` (`code`),
  KEY `airlines_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airlines`
--

LOCK TABLES `airlines` WRITE;
/*!40000 ALTER TABLE `airlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `airlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visa_id` bigint(20) unsigned NOT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_created_by_foreign` (`created_by`),
  KEY `appointments_updated_by_foreign` (`updated_by`),
  KEY `appointments_visa_id_index` (`visa_id`),
  KEY `appointments_status_index` (`status`),
  CONSTRAINT `appointments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_visa_id_foreign` FOREIGN KEY (`visa_id`) REFERENCES `visas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arrival_supports`
--

DROP TABLE IF EXISTS `arrival_supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arrival_supports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_arrival_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  `resolved_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `arrival_supports_created_by_foreign` (`created_by`),
  KEY `arrival_supports_updated_by_foreign` (`updated_by`),
  KEY `arrival_supports_post_arrival_id_index` (`post_arrival_id`),
  KEY `arrival_supports_status_index` (`status`),
  CONSTRAINT `arrival_supports_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `arrival_supports_post_arrival_id_foreign` FOREIGN KEY (`post_arrival_id`) REFERENCES `post_arrivals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `arrival_supports_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arrival_supports`
--

LOCK TABLES `arrival_supports` WRITE;
/*!40000 ALTER TABLE `arrival_supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `arrival_supports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `check_in` datetime DEFAULT NULL,
  `check_out` datetime DEFAULT NULL,
  `status` enum('present','late','absent','leave') NOT NULL DEFAULT 'present',
  `source` enum('manual','biometric') NOT NULL DEFAULT 'manual',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendances_employee_id_index` (`employee_id`),
  KEY `attendances_date_index` (`date`),
  KEY `attendances_status_index` (`status`),
  CONSTRAINT `attendances_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `auditable_type` varchar(255) DEFAULT NULL,
  `auditable_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_auditable_type_index` (`auditable_type`),
  KEY `audit_logs_auditable_id_index` (`auditable_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'created','App\\Models\\Recruitment',3,NULL,'{\"passport_holder_id\":\"1\",\"agent_id\":null,\"branch_id\":\"1\",\"country_id\":\"9\",\"company_id\":\"1\",\"position_id\":\"7\",\"expected_salary\":\"1200\",\"remarks\":null,\"financial_responsible_type\":null,\"financial_responsible_id\":null,\"tracking_number\":\"2026-0001-000001\",\"current_stage\":\"registration\",\"current_status\":\"pending\",\"updated_at\":\"2026-11-20 16:40:22\",\"created_at\":\"2026-11-20 16:40:22\",\"id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(2,1,'updated','App\\Models\\Recruitment',3,'{\"created_by\":null,\"updated_by\":null}','{\"created_by\":1,\"updated_by\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(3,1,'created','App\\Models\\RecruitmentDocument',3,NULL,'{\"recruitment_id\":3,\"type\":\"passport_scan\",\"stage\":\"registration\",\"file_path\":\"recruitments\\/3\\/nL6hgDRA65F6jm7PkTxdcNVD9tmiNWAyfbc1fk6L.png\",\"original_name\":\"Larave_vue.png\",\"mime_type\":\"image\\/png\",\"size\":306846,\"uploaded_by\":1,\"updated_at\":\"2026-11-20 16:40:22\",\"created_at\":\"2026-11-20 16:40:22\",\"id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(4,1,'created','App\\Models\\RecruitmentStageHistory',3,NULL,'{\"recruitment_id\":3,\"stage\":\"registration\",\"status\":\"pending\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:40:22\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:40:22\",\"created_at\":\"2026-11-20 16:40:22\",\"id\":3}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(5,1,'recruitment.initial_registration',NULL,NULL,'[]','{\"current_stage\":\"registration\",\"current_status\":\"pending\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(6,1,'request.post',NULL,NULL,NULL,'{\"route\":\"recruitments.store\",\"path\":\"recruitments\",\"fields\":[\"_token\",\"passport_holder_id\",\"agent_id\",\"branch_id\",\"country_id\",\"company_id\",\"position_id\",\"expected_salary\",\"remarks\",\"documents\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:40:22','2026-11-20 10:40:22'),(7,1,'request.post',NULL,NULL,NULL,'{\"route\":\"selections.store\",\"path\":\"selections\",\"fields\":[\"_token\",\"recruitment_id\",\"grade\",\"status\",\"decided_at\",\"remarks\",\"financial_responsible_type\",\"financial_responsible_id\",\"salary\",\"company_service_charge\",\"agent_charge\",\"medical_cost\",\"training_cost\",\"visa_cost\",\"other_cost\",\"advance_amount\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:33','2026-11-20 10:44:33'),(8,1,'created','App\\Models\\Selection',1,NULL,'{\"recruitment_id\":\"3\",\"grade\":\"A+\",\"status\":\"pending\",\"decided_at\":\"2026-11-20 00:00:00\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:44:54\",\"created_at\":\"2026-11-20 16:44:54\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:54','2026-11-20 10:44:54'),(9,1,'created','App\\Models\\RecruitmentStageHistory',4,NULL,'{\"recruitment_id\":3,\"stage\":\"selection\",\"status\":\"pending\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:44:54\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:44:54\",\"created_at\":\"2026-11-20 16:44:54\",\"id\":4}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:54','2026-11-20 10:44:54'),(10,1,'updated','App\\Models\\Recruitment',3,'{\"current_stage\":\"registration\",\"updated_at\":\"\\\"2026-11-20T10:40:22.000000Z\\\"\"}','{\"current_stage\":\"selection\",\"updated_at\":\"2026-11-20 16:44:54\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:54','2026-11-20 10:44:54'),(11,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"selection\",\"status\":\"pending\"}','{\"stage\":\"selection\",\"status\":\"pending\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:54','2026-11-20 10:44:54'),(12,1,'request.post',NULL,NULL,NULL,'{\"route\":\"selections.store\",\"path\":\"selections\",\"fields\":[\"_token\",\"recruitment_id\",\"grade\",\"status\",\"decided_at\",\"remarks\",\"financial_responsible_type\",\"financial_responsible_id\",\"salary\",\"company_service_charge\",\"agent_charge\",\"medical_cost\",\"training_cost\",\"visa_cost\",\"other_cost\",\"advance_amount\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:44:54','2026-11-20 10:44:54'),(13,1,'updated','App\\Models\\Selection',1,'{\"status\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:44:54.000000Z\\\"\"}','{\"status\":\"approved\",\"updated_at\":\"2026-11-20 16:45:09\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:45:09','2026-11-20 10:45:09'),(14,1,'created','App\\Models\\RecruitmentStageHistory',5,NULL,'{\"recruitment_id\":3,\"stage\":\"selection\",\"status\":\"approved\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:45:09\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:45:09\",\"created_at\":\"2026-11-20 16:45:09\",\"id\":5}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:45:09','2026-11-20 10:45:09'),(15,1,'updated','App\\Models\\Recruitment',3,'{\"current_status\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:44:54.000000Z\\\"\"}','{\"current_status\":\"approved\",\"updated_at\":\"2026-11-20 16:45:09\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:45:09','2026-11-20 10:45:09'),(16,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"selection\",\"status\":\"approved\"}','{\"stage\":\"selection\",\"status\":\"approved\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:45:09','2026-11-20 10:45:09'),(17,1,'request.post',NULL,NULL,NULL,'{\"route\":\"selections.status\",\"path\":\"selections\\/1\\/status\",\"fields\":[\"_token\",\"status\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:45:09','2026-11-20 10:45:09'),(18,1,'created','App\\Models\\Delegation',1,NULL,'{\"recruitment_id\":\"3\",\"status\":\"pending\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:46:47\",\"created_at\":\"2026-11-20 16:46:47\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:47','2026-11-20 10:46:47'),(19,1,'created','App\\Models\\RecruitmentStageHistory',6,NULL,'{\"recruitment_id\":3,\"stage\":\"delegation\",\"status\":\"pending\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:46:47\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:46:47\",\"created_at\":\"2026-11-20 16:46:47\",\"id\":6}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:47','2026-11-20 10:46:47'),(20,1,'updated','App\\Models\\Recruitment',3,'{\"current_stage\":\"selection\",\"current_status\":\"approved\",\"updated_at\":\"\\\"2026-11-20T10:45:09.000000Z\\\"\"}','{\"current_stage\":\"delegation\",\"current_status\":\"pending\",\"updated_at\":\"2026-11-20 16:46:47\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:47','2026-11-20 10:46:47'),(21,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"delegation\",\"status\":\"pending\"}','{\"stage\":\"delegation\",\"status\":\"pending\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:47','2026-11-20 10:46:47'),(22,1,'request.post',NULL,NULL,NULL,'{\"route\":\"delegations.store\",\"path\":\"delegations\",\"fields\":[\"_token\",\"recruitment_id\",\"status\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:47','2026-11-20 10:46:47'),(23,1,'updated','App\\Models\\Delegation',1,'{\"status\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:46:47.000000Z\\\"\"}','{\"status\":\"approved\",\"updated_at\":\"2026-11-20 16:46:58\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:58','2026-11-20 10:46:58'),(24,1,'created','App\\Models\\RecruitmentStageHistory',7,NULL,'{\"recruitment_id\":3,\"stage\":\"delegation\",\"status\":\"approved\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:46:58\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:46:58\",\"created_at\":\"2026-11-20 16:46:58\",\"id\":7}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:58','2026-11-20 10:46:58'),(25,1,'updated','App\\Models\\Recruitment',3,'{\"current_status\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:46:47.000000Z\\\"\"}','{\"current_status\":\"approved\",\"updated_at\":\"2026-11-20 16:46:58\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:58','2026-11-20 10:46:58'),(26,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"delegation\",\"status\":\"approved\"}','{\"stage\":\"delegation\",\"status\":\"approved\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:58','2026-11-20 10:46:58'),(27,1,'request.post',NULL,NULL,NULL,'{\"route\":\"delegations.status\",\"path\":\"delegations\\/1\\/status\",\"fields\":[\"_token\",\"status\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:46:58','2026-11-20 10:46:58'),(28,1,'created','App\\Models\\MedicalCentre',1,NULL,'{\"name\":\"jmn jk\",\"address\":null,\"phone\":null,\"email\":null,\"status\":\"active\",\"updated_at\":\"2026-11-20 16:47:41\",\"created_at\":\"2026-11-20 16:47:41\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:47:41','2026-11-20 10:47:41'),(29,1,'request.post',NULL,NULL,NULL,'{\"route\":\"medical-centres.store\",\"path\":\"medical-centres\",\"fields\":[\"_token\",\"name\",\"phone\",\"email\",\"status\",\"address\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:47:41','2026-11-20 10:47:41'),(30,1,'created','App\\Models\\Medical',1,NULL,'{\"recruitment_id\":\"3\",\"medical_centre_id\":\"1\",\"medical_date\":\"2026-11-20 00:00:00\",\"result\":\"pending\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:48:15\",\"created_at\":\"2026-11-20 16:48:15\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:15','2026-11-20 10:48:15'),(31,1,'created','App\\Models\\RecruitmentStageHistory',8,NULL,'{\"recruitment_id\":3,\"stage\":\"medical\",\"status\":\"pending\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:48:15\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:48:15\",\"created_at\":\"2026-11-20 16:48:15\",\"id\":8}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:15','2026-11-20 10:48:15'),(32,1,'updated','App\\Models\\Recruitment',3,'{\"current_stage\":\"delegation\",\"current_status\":\"approved\",\"updated_at\":\"\\\"2026-11-20T10:46:58.000000Z\\\"\"}','{\"current_stage\":\"medical\",\"current_status\":\"pending\",\"updated_at\":\"2026-11-20 16:48:15\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:15','2026-11-20 10:48:15'),(33,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"medical\",\"status\":\"pending\"}','{\"stage\":\"medical\",\"status\":\"pending\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:15','2026-11-20 10:48:15'),(34,1,'request.post',NULL,NULL,NULL,'{\"route\":\"medicals.store\",\"path\":\"medicals\",\"fields\":[\"_token\",\"recruitment_id\",\"medical_centre_id\",\"medical_date\",\"result\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:15','2026-11-20 10:48:15'),(35,1,'updated','App\\Models\\Medical',1,'{\"result\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:48:15.000000Z\\\"\"}','{\"result\":\"fit\",\"updated_at\":\"2026-11-20 16:48:34\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:34','2026-11-20 10:48:34'),(36,1,'created','App\\Models\\RecruitmentStageHistory',9,NULL,'{\"recruitment_id\":3,\"stage\":\"medical\",\"status\":\"fit\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:48:34\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:48:34\",\"created_at\":\"2026-11-20 16:48:34\",\"id\":9}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:34','2026-11-20 10:48:34'),(37,1,'updated','App\\Models\\Recruitment',3,'{\"current_status\":\"pending\",\"updated_at\":\"\\\"2026-11-20T10:48:15.000000Z\\\"\"}','{\"current_status\":\"fit\",\"updated_at\":\"2026-11-20 16:48:34\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:34','2026-11-20 10:48:34'),(38,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"medical\",\"status\":\"fit\"}','{\"stage\":\"medical\",\"status\":\"fit\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:34','2026-11-20 10:48:34'),(39,1,'request.post',NULL,NULL,NULL,'{\"route\":\"medicals.status\",\"path\":\"medicals\\/1\\/status\",\"fields\":[\"_token\",\"status\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:48:34','2026-11-20 10:48:34'),(40,1,'created','App\\Models\\PoliceClearance',1,NULL,'{\"recruitment_id\":\"3\",\"status\":\"cleared\",\"issue_date\":\"2026-11-20 00:00:00\",\"expiry_date\":\"2026-11-20 00:00:00\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:49:20\",\"created_at\":\"2026-11-20 16:49:20\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(41,1,'created','App\\Models\\RecruitmentStageHistory',10,NULL,'{\"recruitment_id\":3,\"stage\":\"police_clearance\",\"status\":\"pending\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:49:20\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:49:20\",\"created_at\":\"2026-11-20 16:49:20\",\"id\":10}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(42,1,'updated','App\\Models\\Recruitment',3,'{\"current_stage\":\"medical\",\"current_status\":\"fit\",\"updated_at\":\"\\\"2026-11-20T10:48:34.000000Z\\\"\"}','{\"current_stage\":\"police_clearance\",\"current_status\":\"pending\",\"updated_at\":\"2026-11-20 16:49:20\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(43,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"police_clearance\",\"status\":\"pending\"}','{\"stage\":\"police_clearance\",\"status\":\"pending\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(44,1,'created','App\\Models\\RecruitmentStageHistory',11,NULL,'{\"recruitment_id\":3,\"stage\":\"police_clearance\",\"status\":\"cleared\",\"changed_by\":1,\"changed_at\":\"2026-11-20 16:49:20\",\"remarks\":null,\"updated_at\":\"2026-11-20 16:49:20\",\"created_at\":\"2026-11-20 16:49:20\",\"id\":11}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(45,1,'updated','App\\Models\\Recruitment',3,'{\"current_status\":\"pending\"}','{\"current_status\":\"cleared\"}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(46,1,'workflow.transition','App\\Models\\Recruitment',3,'{\"stage\":\"police_clearance\",\"status\":\"cleared\"}','{\"stage\":\"police_clearance\",\"status\":\"cleared\",\"remarks\":null}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:20','2026-11-20 10:49:20'),(47,1,'request.post',NULL,NULL,NULL,'{\"route\":\"police-clearances.store\",\"path\":\"police-clearances\",\"fields\":[\"_token\",\"recruitment_id\",\"status\",\"issue_date\",\"expiry_date\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:21','2026-11-20 10:49:21'),(48,1,'request.post',NULL,NULL,NULL,'{\"route\":\"police-clearances.status\",\"path\":\"police-clearances\\/1\\/status\",\"fields\":[\"_token\",\"status\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:49:33','2026-11-20 10:49:33'),(49,1,'created','App\\Models\\TrainingCentre',1,NULL,'{\"name\":\"polpol.p\",\"address\":null,\"phone\":null,\"email\":null,\"status\":\"active\",\"updated_at\":\"2026-11-20 16:52:01\",\"created_at\":\"2026-11-20 16:52:01\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:52:01','2026-11-20 10:52:01'),(50,1,'request.post',NULL,NULL,NULL,'{\"route\":\"training-centres.store\",\"path\":\"training-centres\",\"fields\":[\"_token\",\"name\",\"phone\",\"email\",\"status\",\"address\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:52:01','2026-11-20 10:52:01'),(51,1,'created','App\\Models\\TrainingCourse',1,NULL,'{\"training_centre_id\":\"1\",\"title\":\"moik,po\",\"duration_days\":\"30\",\"fee\":\"300\",\"status\":\"active\",\"updated_at\":\"2026-11-20 16:52:39\",\"created_at\":\"2026-11-20 16:52:39\",\"id\":1}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:52:39','2026-11-20 10:52:39'),(52,1,'request.post',NULL,NULL,NULL,'{\"route\":\"training-courses.store\",\"path\":\"training-courses\",\"fields\":[\"_token\",\"title\",\"training_centre_id\",\"duration_days\",\"fee\",\"status\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:52:39','2026-11-20 10:52:39'),(54,1,'request.post',NULL,NULL,NULL,'{\"route\":\"trainings.store\",\"path\":\"trainings\",\"fields\":[\"_token\",\"recruitment_id\",\"training_centre_id\",\"course_id\",\"start_date\",\"end_date\",\"attendance_percentage\",\"result\",\"remarks\"]}','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 10:53:27','2026-11-20 10:53:27');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `type` enum('db','files','full') NOT NULL DEFAULT 'full',
  `size` int(11) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `status` enum('pending','completed','failed','verified') NOT NULL DEFAULT 'pending',
  `path` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_status_index` (`status`),
  KEY `backups_type_index` (`type`),
  KEY `backups_created_by_index` (`created_by`),
  CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_code_unique` (`code`),
  KEY `branches_manager_id_foreign` (`manager_id`),
  KEY `branches_created_by_foreign` (`created_by`),
  KEY `branches_updated_by_foreign` (`updated_by`),
  KEY `branches_status_index` (`status`),
  CONSTRAINT `branches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `branches_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `branches_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'Test branch','0001',NULL,'01334334457','infojewel77@gmail.com',1,'active',1,1,'2026-11-20 10:30:22','2026-11-20 10:30:22',NULL);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(191) NOT NULL,
  `value` text NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `country_id` bigint(20) unsigned NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_created_by_foreign` (`created_by`),
  KEY `companies_updated_by_foreign` (`updated_by`),
  KEY `companies_status_index` (`status`),
  KEY `companies_country_id_index` (`country_id`),
  CONSTRAINT `companies_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`),
  CONSTRAINT `companies_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `companies_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Sample Construction Co.',1,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(2,'Sample Cleaning Services LLC',1,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(3,'Sample Hospitality Group',4,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(4,'Sample Facilities Management',3,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(5,'Sample Trading & Contracting',7,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(6,'Sample Manpower Services',2,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(7,'Sample Plantation Berhad',2,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(8,'Sample Shipbuilding Pte Ltd',8,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(9,'Sample Hotels Ltd',9,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(10,'Sample Logistics SRL',10,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_profiles`
--

DROP TABLE IF EXISTS `company_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `software_name` varchar(255) NOT NULL DEFAULT 'Manpower Recruitment & Overseas Employment ERP',
  `software_short_name` varchar(255) NOT NULL DEFAULT 'Manpower ERP',
  `logo_path` varchar(255) DEFAULT NULL,
  `favicon_path` varchar(255) DEFAULT NULL,
  `login_background_path` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `primary_color` varchar(20) NOT NULL DEFAULT '#0d6efd',
  `secondary_color` varchar(20) NOT NULL DEFAULT '#6c757d',
  `currency` varchar(10) NOT NULL DEFAULT 'BDT',
  `language` varchar(10) NOT NULL DEFAULT 'en',
  `timezone` varchar(255) NOT NULL DEFAULT 'Asia/Dhaka',
  `date_format` varchar(255) NOT NULL DEFAULT 'd-m-Y',
  `invoice_prefix` varchar(255) NOT NULL DEFAULT 'INV',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_profiles`
--

LOCK TABLES `company_profiles` WRITE;
/*!40000 ALTER TABLE `company_profiles` DISABLE KEYS */;
INSERT INTO `company_profiles` VALUES (1,'','Manpower Recruitment & Overseas Employment ERP','Manpower ERP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'#0d6efd','#6c757d','BDT','en','Asia/Dhaka','d-m-Y','INV',1,'2026-11-20 10:15:15','2026-11-20 10:15:15');
/*!40000 ALTER TABLE `company_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_arrival_id` bigint(20) unsigned DEFAULT NULL,
  `recruitment_id` bigint(20) unsigned DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  `raised_by` bigint(20) unsigned DEFAULT NULL,
  `resolved_by` bigint(20) unsigned DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaints_raised_by_foreign` (`raised_by`),
  KEY `complaints_resolved_by_foreign` (`resolved_by`),
  KEY `complaints_created_by_foreign` (`created_by`),
  KEY `complaints_updated_by_foreign` (`updated_by`),
  KEY `complaints_post_arrival_id_index` (`post_arrival_id`),
  KEY `complaints_recruitment_id_index` (`recruitment_id`),
  KEY `complaints_status_index` (`status`),
  CONSTRAINT `complaints_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_post_arrival_id_foreign` FOREIGN KEY (`post_arrival_id`) REFERENCES `post_arrivals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `complaints_raised_by_foreign` FOREIGN KEY (`raised_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_resolved_by_foreign` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaints`
--

LOCK TABLES `complaints` WRITE;
/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `countries_code_unique` (`code`),
  KEY `countries_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Saudi Arabia','SA','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(2,'Malaysia','MY','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(3,'Qatar','QA','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(4,'United Arab Emirates','AE','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(5,'Oman','OM','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(6,'Bahrain','BH','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(7,'Kuwait','KW','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(8,'Singapore','SG','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(9,'Malta','MT','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(10,'Romania','RO','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(11,'Poland','PL','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(12,'Croatia','HR','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(13,'Serbia','RS','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(14,'Bulgaria','BG','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(15,'Hungary','HU','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(16,'Jordan','JO','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(17,'Lebanon','LB','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(18,'Brunei','BN','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(19,'South Korea','KR','active','2026-11-20 10:15:16','2026-11-20 10:15:16'),(20,'Japan','JP','active','2026-11-20 10:15:16','2026-11-20 10:15:16');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delegation_documents`
--

DROP TABLE IF EXISTS `delegation_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delegation_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `delegation_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delegation_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `delegation_documents_created_by_foreign` (`created_by`),
  KEY `delegation_documents_updated_by_foreign` (`updated_by`),
  KEY `delegation_documents_delegation_id_index` (`delegation_id`),
  KEY `delegation_documents_type_index` (`type`),
  CONSTRAINT `delegation_documents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delegation_documents_delegation_id_foreign` FOREIGN KEY (`delegation_id`) REFERENCES `delegations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delegation_documents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delegation_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delegation_documents`
--

LOCK TABLES `delegation_documents` WRITE;
/*!40000 ALTER TABLE `delegation_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `delegation_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delegations`
--

DROP TABLE IF EXISTS `delegations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delegations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','approved','rejected','returned','cancelled') NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `decided_by` bigint(20) unsigned DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delegations_decided_by_foreign` (`decided_by`),
  KEY `delegations_created_by_foreign` (`created_by`),
  KEY `delegations_updated_by_foreign` (`updated_by`),
  KEY `delegations_recruitment_id_index` (`recruitment_id`),
  KEY `delegations_status_index` (`status`),
  CONSTRAINT `delegations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delegations_decided_by_foreign` FOREIGN KEY (`decided_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delegations_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delegations_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delegations`
--

LOCK TABLES `delegations` WRITE;
/*!40000 ALTER TABLE `delegations` DISABLE KEYS */;
INSERT INTO `delegations` VALUES (1,3,'approved',NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:46:47','2026-11-20 10:46:58',NULL);
/*!40000 ALTER TABLE `delegations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_code_unique` (`code`),
  KEY `departments_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designations`
--

DROP TABLE IF EXISTS `designations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designations_status_index` (`status`),
  KEY `designations_department_id_index` (`department_id`),
  CONSTRAINT `designations_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designations`
--

LOCK TABLES `designations` WRITE;
/*!40000 ALTER TABLE `designations` DISABLE KEYS */;
/*!40000 ALTER TABLE `designations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_documents`
--

DROP TABLE IF EXISTS `employee_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `type` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `employee_documents_employee_id_index` (`employee_id`),
  CONSTRAINT `employee_documents_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_documents`
--

LOCK TABLES `employee_documents` WRITE;
/*!40000 ALTER TABLE `employee_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `designation_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `employee_code` varchar(255) NOT NULL,
  `joining_date` date DEFAULT NULL,
  `salary` decimal(15,2) DEFAULT NULL,
  `status` enum('active','inactive','terminated') NOT NULL DEFAULT 'active',
  `phone` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_employee_code_unique` (`employee_code`),
  KEY `employees_user_id_foreign` (`user_id`),
  KEY `employees_designation_id_foreign` (`designation_id`),
  KEY `employees_created_by_foreign` (`created_by`),
  KEY `employees_updated_by_foreign` (`updated_by`),
  KEY `employees_status_index` (`status`),
  KEY `employees_branch_id_index` (`branch_id`),
  KEY `employees_department_id_index` (`department_id`),
  CONSTRAINT `employees_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` text NOT NULL,
  `exception` text NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fingerprints`
--

DROP TABLE IF EXISTS `fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fingerprints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `appointment_date` date DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `status` enum('pending','submitted','completed','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `reference_number` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fingerprints_created_by_foreign` (`created_by`),
  KEY `fingerprints_updated_by_foreign` (`updated_by`),
  KEY `fingerprints_recruitment_id_index` (`recruitment_id`),
  KEY `fingerprints_status_index` (`status`),
  CONSTRAINT `fingerprints_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fingerprints_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fingerprints_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fingerprints`
--

LOCK TABLES `fingerprints` WRITE;
/*!40000 ALTER TABLE `fingerprints` DISABLE KEYS */;
/*!40000 ALTER TABLE `fingerprints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiscal_periods`
--

DROP TABLE IF EXISTS `fiscal_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fiscal_periods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fiscal_periods_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiscal_periods`
--

LOCK TABLES `fiscal_periods` WRITE;
/*!40000 ALTER TABLE `fiscal_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiscal_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flights`
--

DROP TABLE IF EXISTS `flights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flights` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `airline_id` bigint(20) unsigned DEFAULT NULL,
  `flight_number` varchar(255) DEFAULT NULL,
  `travel_agency_id` bigint(20) unsigned DEFAULT NULL,
  `departure_date` datetime DEFAULT NULL,
  `departure_airport` varchar(255) DEFAULT NULL,
  `arrival_airport` varchar(255) DEFAULT NULL,
  `ticket_number` varchar(255) DEFAULT NULL,
  `ticket_path` varchar(255) DEFAULT NULL,
  `noc_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','ticket_issued','cancelled','rescheduled') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flights_airline_id_foreign` (`airline_id`),
  KEY `flights_travel_agency_id_foreign` (`travel_agency_id`),
  KEY `flights_created_by_foreign` (`created_by`),
  KEY `flights_updated_by_foreign` (`updated_by`),
  KEY `flights_recruitment_id_index` (`recruitment_id`),
  KEY `flights_status_index` (`status`),
  CONSTRAINT `flights_airline_id_foreign` FOREIGN KEY (`airline_id`) REFERENCES `airlines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `flights_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `flights_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `flights_travel_agency_id_foreign` FOREIGN KEY (`travel_agency_id`) REFERENCES `travel_agencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `flights_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flights`
--

LOCK TABLES `flights` WRITE;
/*!40000 ALTER TABLE `flights` DISABLE KEYS */;
/*!40000 ALTER TABLE `flights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grading_criteria`
--

DROP TABLE IF EXISTS `grading_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grading_criteria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `max_score` decimal(15,2) NOT NULL DEFAULT 100.00,
  `weight` decimal(15,2) NOT NULL DEFAULT 1.00,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grading_criteria_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grading_criteria`
--

LOCK TABLES `grading_criteria` WRITE;
/*!40000 ALTER TABLE `grading_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `grading_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `type` enum('public','company','religious') NOT NULL DEFAULT 'public',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `holidays_date_index` (`date`),
  KEY `holidays_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` text NOT NULL,
  `options` text DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` text NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT 0,
  `reserved_at` int(11) DEFAULT NULL,
  `available_at` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entries`
--

DROP TABLE IF EXISTS `journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `voucher_id` bigint(20) unsigned NOT NULL,
  `entry_date` date NOT NULL,
  `narration` text DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journal_entries_voucher_id_foreign` (`voucher_id`),
  KEY `journal_entries_created_by_foreign` (`created_by`),
  KEY `journal_entries_updated_by_foreign` (`updated_by`),
  KEY `journal_entries_branch_id_index` (`branch_id`),
  KEY `journal_entries_entry_date_index` (`entry_date`),
  CONSTRAINT `journal_entries_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journal_entries_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journal_entries_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journal_entries_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entries`
--

LOCK TABLES `journal_entries` WRITE;
/*!40000 ALTER TABLE `journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entry_lines`
--

DROP TABLE IF EXISTS `journal_entry_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_entry_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `journal_entry_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `sub_ledger_type` varchar(255) DEFAULT NULL,
  `sub_ledger_id` bigint(20) unsigned DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journal_entry_lines_journal_entry_id_foreign` (`journal_entry_id`),
  KEY `journal_entry_lines_account_id_index` (`account_id`),
  KEY `journal_entry_lines_sub_ledger_type_index` (`sub_ledger_type`),
  KEY `journal_entry_lines_sub_ledger_id_index` (`sub_ledger_id`),
  CONSTRAINT `journal_entry_lines_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `journal_entry_lines_journal_entry_id_foreign` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entry_lines`
--

LOCK TABLES `journal_entry_lines` WRITE;
/*!40000 ALTER TABLE `journal_entry_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entry_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leaves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `type` enum('casual','sick','annual','unpaid','other') NOT NULL DEFAULT 'casual',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `reason` text DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leaves_approved_by_foreign` (`approved_by`),
  KEY `leaves_created_by_foreign` (`created_by`),
  KEY `leaves_updated_by_foreign` (`updated_by`),
  KEY `leaves_employee_id_index` (`employee_id`),
  KEY `leaves_status_index` (`status`),
  KEY `leaves_start_date_index` (`start_date`),
  CONSTRAINT `leaves_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leaves_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leaves_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leaves_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaves`
--

LOCK TABLES `leaves` WRITE;
/*!40000 ALTER TABLE `leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_histories`
--

DROP TABLE IF EXISTS `login_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_at` datetime DEFAULT NULL,
  `logout_at` datetime DEFAULT NULL,
  `status` enum('success','failed','locked') NOT NULL DEFAULT 'success',
  `failed_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_histories_user_id_index` (`user_id`),
  KEY `login_histories_status_index` (`status`),
  KEY `login_histories_login_at_index` (`login_at`),
  CONSTRAINT `login_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_histories`
--

LOCK TABLES `login_histories` WRITE;
/*!40000 ALTER TABLE `login_histories` DISABLE KEYS */;
INSERT INTO `login_histories` VALUES (1,1,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','2026-11-20 16:17:06',NULL,'success',NULL,'2026-11-20 10:17:06','2026-11-20 10:17:06');
/*!40000 ALTER TABLE `login_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manpower_approvals`
--

DROP TABLE IF EXISTS `manpower_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manpower_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `approval_reference` varchar(255) DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `status` enum('pending','approved','rejected','returned','cancelled') NOT NULL DEFAULT 'pending',
  `documents_path` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `manpower_approvals_created_by_foreign` (`created_by`),
  KEY `manpower_approvals_updated_by_foreign` (`updated_by`),
  KEY `manpower_approvals_recruitment_id_index` (`recruitment_id`),
  KEY `manpower_approvals_status_index` (`status`),
  CONSTRAINT `manpower_approvals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `manpower_approvals_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `manpower_approvals_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manpower_approvals`
--

LOCK TABLES `manpower_approvals` WRITE;
/*!40000 ALTER TABLE `manpower_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `manpower_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_centres`
--

DROP TABLE IF EXISTS `medical_centres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_centres` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medical_centres_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_centres`
--

LOCK TABLES `medical_centres` WRITE;
/*!40000 ALTER TABLE `medical_centres` DISABLE KEYS */;
INSERT INTO `medical_centres` VALUES (1,'jmn jk',NULL,NULL,NULL,'active','2026-11-20 10:47:41','2026-11-20 10:47:41');
/*!40000 ALTER TABLE `medical_centres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicals`
--

DROP TABLE IF EXISTS `medicals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `medical_centre_id` bigint(20) unsigned DEFAULT NULL,
  `medical_date` date DEFAULT NULL,
  `result` enum('pending','fit','unfit','expired','cancelled') NOT NULL DEFAULT 'pending',
  `report_path` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `reassessment_of` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medicals_medical_centre_id_foreign` (`medical_centre_id`),
  KEY `medicals_reassessment_of_foreign` (`reassessment_of`),
  KEY `medicals_created_by_foreign` (`created_by`),
  KEY `medicals_updated_by_foreign` (`updated_by`),
  KEY `medicals_recruitment_id_index` (`recruitment_id`),
  KEY `medicals_result_index` (`result`),
  CONSTRAINT `medicals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medicals_medical_centre_id_foreign` FOREIGN KEY (`medical_centre_id`) REFERENCES `medical_centres` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medicals_reassessment_of_foreign` FOREIGN KEY (`reassessment_of`) REFERENCES `medicals` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medicals_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medicals_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicals`
--

LOCK TABLES `medicals` WRITE;
/*!40000 ALTER TABLE `medicals` DISABLE KEYS */;
INSERT INTO `medicals` VALUES (1,3,1,'2026-11-20','fit',NULL,NULL,NULL,NULL,NULL,'2026-11-20 10:48:15','2026-11-20 10:48:34',NULL);
/*!40000 ALTER TABLE `medicals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_11_12_000001_create_password_reset_tokens_table',1),(2,'2026_11_12_000002_create_sessions_table',1),(3,'2026_11_12_000003_create_cache_table',1),(4,'2026_11_12_000004_create_jobs_table',1),(5,'2026_11_12_000005_create_job_batches_table',1),(6,'2026_11_12_000006_create_failed_jobs_table',1),(7,'2026_11_12_000007_create_personal_access_tokens_table',1),(8,'2026_11_12_000008_create_users_table',1),(9,'2026_11_12_000009_create_branches_table',1),(10,'2026_11_12_000010_add_branch_id_foreign_to_users_table',1),(11,'2026_11_12_000011_create_countries_table',1),(12,'2026_11_12_000012_create_companies_table',1),(13,'2026_11_12_000013_create_positions_table',1),(14,'2026_11_12_000014_create_settings_table',1),(15,'2026_11_12_000015_create_company_profiles_table',1),(16,'2026_11_12_000016_create_departments_table',1),(17,'2026_11_12_000017_create_designations_table',1),(18,'2026_11_12_000018_create_agents_table',1),(19,'2026_11_12_000019_create_agent_country_table',1),(20,'2026_11_12_000020_create_agent_documents_table',1),(21,'2026_11_12_000021_create_passport_holders_table',1),(22,'2026_11_12_000022_create_passport_holder_documents_table',1),(23,'2026_11_12_000023_create_account_types_table',1),(24,'2026_11_12_000024_create_accounts_table',1),(25,'2026_11_12_000025_create_fiscal_periods_table',1),(26,'2026_11_12_000026_create_vouchers_table',1),(27,'2026_11_12_000027_create_journal_entries_table',1),(28,'2026_11_12_000028_create_journal_entry_lines_table',1),(29,'2026_11_12_000029_create_employees_table',1),(30,'2026_11_12_000030_create_attendances_table',1),(31,'2026_11_12_000031_create_leaves_table',1),(32,'2026_11_12_000032_create_holidays_table',1),(33,'2026_11_12_000033_create_salary_structures_table',1),(34,'2026_11_12_000034_create_payrolls_table',1),(35,'2026_11_12_000035_create_payroll_items_table',1),(36,'2026_11_12_000036_create_visitors_table',1),(37,'2026_11_12_000037_create_visitor_passes_table',1),(38,'2026_11_12_000038_create_medical_centres_table',1),(39,'2026_11_12_000039_create_training_centres_table',1),(40,'2026_11_12_000040_create_training_courses_table',1),(41,'2026_11_12_000041_create_grading_criteria_table',1),(42,'2026_11_12_000042_create_recruitments_table',1),(43,'2026_11_12_000043_create_recruitment_stage_histories_table',1),(44,'2026_11_12_000044_create_recruitment_documents_table',1),(45,'2026_11_12_000045_create_tracking_numbers_table',1),(46,'2026_11_12_000046_create_selections_table',1),(47,'2026_11_12_000047_create_selection_grades_table',1),(48,'2026_11_12_000048_create_delegations_table',1),(49,'2026_11_12_000049_create_delegation_documents_table',1),(50,'2026_11_12_000050_create_medicals_table',1),(51,'2026_11_12_000051_create_police_clearances_table',1),(52,'2026_11_12_000052_create_trainings_table',1),(53,'2026_11_12_000053_create_fingerprints_table',1),(54,'2026_11_12_000054_create_manpower_approvals_table',1),(55,'2026_11_12_000055_create_visa_lots_table',1),(56,'2026_11_12_000056_create_visas_table',1),(57,'2026_11_12_000057_create_mofa_processes_table',1),(58,'2026_11_12_000058_create_work_permits_table',1),(59,'2026_11_12_000059_create_appointments_table',1),(60,'2026_11_12_000060_create_passport_returns_table',1),(61,'2026_11_12_000061_create_visa_returns_table',1),(62,'2026_11_12_000062_create_airlines_table',1),(63,'2026_11_12_000063_create_travel_agencies_table',1),(64,'2026_11_12_000064_create_flights_table',1),(65,'2026_11_12_000065_create_post_arrivals_table',1),(66,'2026_11_12_000066_create_arrival_supports_table',1),(67,'2026_11_12_000067_create_complaints_table',1),(68,'2026_11_12_000068_create_audit_logs_table',1),(69,'2026_11_12_000069_create_backups_table',1),(70,'2026_11_12_000070_create_login_histories_table',1),(71,'2026_11_12_000071_create_user_branch_table',1),(72,'2026_11_12_000072_create_user_country_table',1),(73,'2026_11_12_000073_create_permission_tables',1),(74,'2026_11_12_000074_create_employee_documents_table',1),(75,'2026_11_16_000075_sync_navigation_permissions',1),(76,'2026_11_17_000076_add_medical_centre_permissions',1),(77,'2026_11_18_000077_add_training_master_permissions',1),(78,'2026_11_19_000001_add_name_to_employees_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(6,'App\\Models\\User',2),(7,'App\\Models\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mofa_processes`
--

DROP TABLE IF EXISTS `mofa_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mofa_processes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visa_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','submitted','approved','rejected','returned') NOT NULL DEFAULT 'pending',
  `submitted_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mofa_processes_created_by_foreign` (`created_by`),
  KEY `mofa_processes_updated_by_foreign` (`updated_by`),
  KEY `mofa_processes_visa_id_index` (`visa_id`),
  KEY `mofa_processes_status_index` (`status`),
  CONSTRAINT `mofa_processes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mofa_processes_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mofa_processes_visa_id_foreign` FOREIGN KEY (`visa_id`) REFERENCES `visas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mofa_processes`
--

LOCK TABLES `mofa_processes` WRITE;
/*!40000 ALTER TABLE `mofa_processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mofa_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passport_holder_documents`
--

DROP TABLE IF EXISTS `passport_holder_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passport_holder_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `passport_holder_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `passport_holder_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `passport_holder_documents_created_by_foreign` (`created_by`),
  KEY `passport_holder_documents_updated_by_foreign` (`updated_by`),
  KEY `passport_holder_documents_passport_holder_id_index` (`passport_holder_id`),
  KEY `passport_holder_documents_type_index` (`type`),
  CONSTRAINT `passport_holder_documents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holder_documents_passport_holder_id_foreign` FOREIGN KEY (`passport_holder_id`) REFERENCES `passport_holders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `passport_holder_documents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holder_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passport_holder_documents`
--

LOCK TABLES `passport_holder_documents` WRITE;
/*!40000 ALTER TABLE `passport_holder_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `passport_holder_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passport_holders`
--

DROP TABLE IF EXISTS `passport_holders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passport_holders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `company_id` bigint(20) unsigned DEFAULT NULL,
  `position_id` bigint(20) unsigned DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('male','female','other') NOT NULL DEFAULT 'male',
  `nationality` varchar(255) NOT NULL DEFAULT 'Bangladeshi',
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `present_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `nid` varchar(255) DEFAULT NULL,
  `passport_number` varchar(255) DEFAULT NULL,
  `passport_issue_date` date DEFAULT NULL,
  `passport_expiry_date` date DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','completed','cancelled') NOT NULL DEFAULT 'active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `passport_holders_user_id_foreign` (`user_id`),
  KEY `passport_holders_company_id_foreign` (`company_id`),
  KEY `passport_holders_position_id_foreign` (`position_id`),
  KEY `passport_holders_created_by_foreign` (`created_by`),
  KEY `passport_holders_updated_by_foreign` (`updated_by`),
  KEY `passport_holders_status_index` (`status`),
  KEY `passport_holders_country_id_index` (`country_id`),
  KEY `passport_holders_branch_id_index` (`branch_id`),
  KEY `passport_holders_agent_id_index` (`agent_id`),
  KEY `passport_holders_passport_number_index` (`passport_number`),
  CONSTRAINT `passport_holders_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_holders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passport_holders`
--

LOCK TABLES `passport_holders` WRITE;
/*!40000 ALTER TABLE `passport_holders` DISABLE KEYS */;
INSERT INTO `passport_holders` VALUES (1,3,NULL,1,9,1,7,'MD ANOWAR HOSEN','MD FAZU','AUARA','2005-07-08','male','BANGLADESHI','+8801342624634','razibhasan23@gmail.com','Mymensingh','Netrakona Sadar',NULL,'a23054668','2026-07-27','2036-07-26',NULL,'active',1,1,'2026-11-20 10:36:55','2026-11-20 10:36:55',NULL);
/*!40000 ALTER TABLE `passport_holders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passport_returns`
--

DROP TABLE IF EXISTS `passport_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passport_returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `return_date` date DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `return_type` enum('handover','courier','agent_collection','other') NOT NULL DEFAULT 'handover',
  `responsible_person` varchar(255) DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `delivered_to` varchar(255) DEFAULT NULL,
  `identity_verified_by` varchar(255) DEFAULT NULL,
  `acknowledgement_path` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('pending','returned','cancelled') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `passport_returns_created_by_foreign` (`created_by`),
  KEY `passport_returns_updated_by_foreign` (`updated_by`),
  KEY `passport_returns_recruitment_id_index` (`recruitment_id`),
  KEY `passport_returns_status_index` (`status`),
  CONSTRAINT `passport_returns_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `passport_returns_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `passport_returns_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passport_returns`
--

LOCK TABLES `passport_returns` WRITE;
/*!40000 ALTER TABLE `passport_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `passport_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_items`
--

DROP TABLE IF EXISTS `payroll_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint(20) unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  `type` enum('earning','deduction') NOT NULL DEFAULT 'earning',
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_items_payroll_id_index` (`payroll_id`),
  KEY `payroll_items_type_index` (`type`),
  CONSTRAINT `payroll_items_payroll_id_foreign` FOREIGN KEY (`payroll_id`) REFERENCES `payrolls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_items`
--

LOCK TABLES `payroll_items` WRITE;
/*!40000 ALTER TABLE `payroll_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payrolls`
--

DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `month` varchar(255) NOT NULL,
  `gross` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bonus` decimal(15,2) NOT NULL DEFAULT 0.00,
  `overtime` decimal(15,2) NOT NULL DEFAULT 0.00,
  `net` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('draft','approved','paid','cancelled') NOT NULL DEFAULT 'draft',
  `paid_at` datetime DEFAULT NULL,
  `voucher_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_voucher_id_foreign` (`voucher_id`),
  KEY `payrolls_created_by_foreign` (`created_by`),
  KEY `payrolls_updated_by_foreign` (`updated_by`),
  KEY `payrolls_employee_id_index` (`employee_id`),
  KEY `payrolls_month_index` (`month`),
  KEY `payrolls_status_index` (`status`),
  CONSTRAINT `payrolls_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payrolls_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payrolls_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payrolls_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payrolls`
--

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'dashboard.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(2,'core.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(3,'core.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(4,'branch.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(5,'branch.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(6,'branch.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(7,'branch.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(8,'branch.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(9,'user.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(10,'user.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(11,'user.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(12,'user.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(13,'user.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(14,'role.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(15,'role.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(16,'role.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(17,'role.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(18,'role.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(19,'setting.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(20,'setting.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(21,'setting.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(22,'company-profile.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(23,'company-profile.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(24,'company-profile.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(25,'backup.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(26,'backup.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(27,'backup.download','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(28,'backup.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(29,'backup.manage','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(30,'agent.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(31,'agent.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(32,'agent.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(33,'agent.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(34,'agent.print','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(35,'agent.export','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(36,'passport-holder.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(37,'passport-holder.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(38,'passport-holder.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(39,'passport-holder.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(40,'passport-holder.print','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(41,'passport-holder.export','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(42,'passport-holder.download','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(43,'recruitment.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(44,'recruitment.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(45,'recruitment.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(46,'recruitment.delete','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(47,'recruitment.approve','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(48,'recruitment.reject','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(49,'recruitment.return','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(50,'recruitment.print','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(51,'recruitment.export','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(52,'selection.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(53,'selection.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(54,'selection.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(55,'selection.approve','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(56,'selection.reject','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(57,'selection.return','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(58,'selection.download','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(59,'delegation.view','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(60,'delegation.create','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(61,'delegation.edit','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(62,'delegation.approve','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(63,'delegation.reject','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(64,'delegation.return','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(65,'delegation.download','web','2026-11-20 10:15:06','2026-11-20 10:15:06'),(66,'medical.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(67,'medical.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(68,'medical.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(69,'medical.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(70,'medical.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(71,'medical.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(72,'medical.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(73,'medical-centre.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(74,'medical-centre.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(75,'medical-centre.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(76,'medical-centre.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(77,'police-clearance.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(78,'police-clearance.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(79,'police-clearance.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(80,'police-clearance.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(81,'police-clearance.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(82,'police-clearance.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(83,'police-clearance.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(84,'training.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(85,'training.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(86,'training.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(87,'training.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(88,'training.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(89,'training.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(90,'training.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(91,'training-centre.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(92,'training-centre.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(93,'training-centre.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(94,'training-centre.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(95,'training-course.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(96,'training-course.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(97,'training-course.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(98,'training-course.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(99,'fingerprint.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(100,'fingerprint.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(101,'fingerprint.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(102,'fingerprint.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(103,'fingerprint.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(104,'fingerprint.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(105,'fingerprint.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(106,'manpower-approval.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(107,'manpower-approval.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(108,'manpower-approval.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(109,'manpower-approval.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(110,'manpower-approval.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(111,'manpower-approval.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(112,'manpower-approval.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(113,'visa.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(114,'visa.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(115,'visa.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(116,'visa.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(117,'visa.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(118,'visa.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(119,'visa.print','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(120,'visa.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(121,'visa.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(122,'flight.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(123,'flight.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(124,'flight.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(125,'flight.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(126,'flight.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(127,'flight.return','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(128,'flight.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(129,'passport-return.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(130,'passport-return.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(131,'passport-return.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(132,'passport-return.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(133,'passport-return.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(134,'passport-return.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(135,'visa-return.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(136,'visa-return.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(137,'visa-return.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(138,'visa-return.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(139,'visa-return.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(140,'visa-return.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(141,'post-arrival.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(142,'post-arrival.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(143,'post-arrival.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(144,'post-arrival.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(145,'post-arrival.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(146,'post-arrival.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(147,'accounting.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(148,'accounting.manage','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(149,'account.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(150,'account.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(151,'account.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(152,'account.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(153,'account.manage','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(154,'account_type.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(155,'account_type.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(156,'account_type.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(157,'account_type.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(158,'account_type.manage','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(159,'voucher.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(160,'voucher.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(161,'voucher.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(162,'voucher.reverse','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(163,'voucher.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(164,'voucher.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(165,'voucher.print','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(166,'voucher.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(167,'ledger.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(168,'ledger.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(169,'ledger.print','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(170,'report.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(171,'report.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(172,'report.print','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(173,'hrm.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(174,'hrm.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(175,'hrm.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(176,'hrm.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(177,'hrm.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(178,'hrm.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(179,'department.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(180,'department.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(181,'department.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(182,'department.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(183,'designation.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(184,'designation.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(185,'designation.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(186,'designation.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(187,'employee.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(188,'employee.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(189,'employee.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(190,'employee.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(191,'attendance.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(192,'attendance.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(193,'attendance.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(194,'attendance.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(195,'holiday.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(196,'holiday.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(197,'holiday.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(198,'holiday.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(199,'leave.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(200,'leave.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(201,'leave.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(202,'leave.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(203,'leave.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(204,'leave.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(205,'salary_structure.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(206,'salary_structure.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(207,'salary_structure.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(208,'salary_structure.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(209,'payroll.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(210,'payroll.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(211,'payroll.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(212,'payroll.pay','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(213,'payroll.approve','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(214,'payroll.reject','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(215,'payroll.print','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(216,'payroll.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(217,'visitor.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(218,'visitor.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(219,'visitor.edit','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(220,'visitor.update','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(221,'visitor.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(222,'audit-log.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(223,'audit-log.export','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(224,'document.view','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(225,'document.download','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(226,'document.create','web','2026-11-20 10:15:07','2026-11-20 10:15:07'),(227,'document.delete','web','2026-11-20 10:15:07','2026-11-20 10:15:07');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_index` (`tokenable_type`),
  KEY `personal_access_tokens_tokenable_id_index` (`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `police_clearances`
--

DROP TABLE IF EXISTS `police_clearances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `police_clearances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','cleared','uncleared','returned','cancelled') NOT NULL DEFAULT 'pending',
  `certificate_path` varchar(255) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `police_clearances_created_by_foreign` (`created_by`),
  KEY `police_clearances_updated_by_foreign` (`updated_by`),
  KEY `police_clearances_recruitment_id_index` (`recruitment_id`),
  KEY `police_clearances_status_index` (`status`),
  CONSTRAINT `police_clearances_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `police_clearances_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `police_clearances_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `police_clearances`
--

LOCK TABLES `police_clearances` WRITE;
/*!40000 ALTER TABLE `police_clearances` DISABLE KEYS */;
INSERT INTO `police_clearances` VALUES (1,3,'cleared',NULL,'2026-11-20','2026-11-20',NULL,NULL,NULL,'2026-11-20 10:49:20','2026-11-20 10:49:20',NULL);
/*!40000 ALTER TABLE `police_clearances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `company_id` bigint(20) unsigned NOT NULL,
  `country_id` bigint(20) unsigned NOT NULL,
  `salary_min` decimal(15,2) DEFAULT NULL,
  `salary_max` decimal(15,2) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'BDT',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `positions_created_by_foreign` (`created_by`),
  KEY `positions_updated_by_foreign` (`updated_by`),
  KEY `positions_status_index` (`status`),
  KEY `positions_company_id_index` (`company_id`),
  KEY `positions_country_id_index` (`country_id`),
  CONSTRAINT `positions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `positions_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`),
  CONSTRAINT `positions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `positions_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,'Construction Worker',1,1,1200.00,1800.00,'SAR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(2,'Cleaner',2,1,1000.00,1400.00,'SAR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(3,'House Driver',1,1,1500.00,2000.00,'SAR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(4,'Waiter',3,4,1200.00,1800.00,'AED','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(5,'Security Guard',4,3,1300.00,1800.00,'QAR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(6,'General Worker',5,7,150.00,220.00,'KWD','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(7,'Factory Worker',6,2,1500.00,2200.00,'MYR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(8,'Plantation Worker',7,2,1400.00,2000.00,'MYR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(9,'Shipyard Worker',8,8,700.00,1100.00,'SGD','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(10,'Hotel Housekeeper',9,9,900.00,1200.00,'EUR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL),(11,'Warehouse Worker',10,10,800.00,1100.00,'EUR','active',NULL,NULL,NULL,'2026-11-20 10:15:16','2026-11-20 10:15:16',NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_arrivals`
--

DROP TABLE IF EXISTS `post_arrivals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_arrivals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `arrival_date` date DEFAULT NULL,
  `airport_pickup` tinyint(1) NOT NULL DEFAULT 0,
  `employer_contact` varchar(255) DEFAULT NULL,
  `accommodation` text DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `status` enum('pending','arrived','settled','issue_reported','completed') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_arrivals_created_by_foreign` (`created_by`),
  KEY `post_arrivals_updated_by_foreign` (`updated_by`),
  KEY `post_arrivals_recruitment_id_index` (`recruitment_id`),
  KEY `post_arrivals_status_index` (`status`),
  CONSTRAINT `post_arrivals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `post_arrivals_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_arrivals_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_arrivals`
--

LOCK TABLES `post_arrivals` WRITE;
/*!40000 ALTER TABLE `post_arrivals` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_arrivals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruitment_documents`
--

DROP TABLE IF EXISTS `recruitment_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruitment_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `stage` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruitment_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `recruitment_documents_created_by_foreign` (`created_by`),
  KEY `recruitment_documents_updated_by_foreign` (`updated_by`),
  KEY `recruitment_documents_recruitment_id_index` (`recruitment_id`),
  KEY `recruitment_documents_type_index` (`type`),
  KEY `recruitment_documents_stage_index` (`stage`),
  CONSTRAINT `recruitment_documents_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitment_documents_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recruitment_documents_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitment_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruitment_documents`
--

LOCK TABLES `recruitment_documents` WRITE;
/*!40000 ALTER TABLE `recruitment_documents` DISABLE KEYS */;
INSERT INTO `recruitment_documents` VALUES (3,3,'passport_scan','registration','recruitments/3/nL6hgDRA65F6jm7PkTxdcNVD9tmiNWAyfbc1fk6L.png','Larave_vue.png','image/png',306846,1,NULL,NULL,'2026-11-20 10:40:22','2026-11-20 10:40:22',NULL);
/*!40000 ALTER TABLE `recruitment_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruitment_stage_histories`
--

DROP TABLE IF EXISTS `recruitment_stage_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruitment_stage_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `stage` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `changed_by` bigint(20) unsigned DEFAULT NULL,
  `changed_at` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruitment_stage_histories_changed_by_foreign` (`changed_by`),
  KEY `recruitment_stage_histories_recruitment_id_index` (`recruitment_id`),
  KEY `recruitment_stage_histories_stage_index` (`stage`),
  KEY `recruitment_stage_histories_status_index` (`status`),
  CONSTRAINT `recruitment_stage_histories_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitment_stage_histories_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruitment_stage_histories`
--

LOCK TABLES `recruitment_stage_histories` WRITE;
/*!40000 ALTER TABLE `recruitment_stage_histories` DISABLE KEYS */;
INSERT INTO `recruitment_stage_histories` VALUES (3,3,'registration','pending',1,'2026-11-20 16:40:22',NULL,'2026-11-20 10:40:22','2026-11-20 10:40:22'),(4,3,'selection','pending',1,'2026-11-20 16:44:54',NULL,'2026-11-20 10:44:54','2026-11-20 10:44:54'),(5,3,'selection','approved',1,'2026-11-20 16:45:09',NULL,'2026-11-20 10:45:09','2026-11-20 10:45:09'),(6,3,'delegation','pending',1,'2026-11-20 16:46:47',NULL,'2026-11-20 10:46:47','2026-11-20 10:46:47'),(7,3,'delegation','approved',1,'2026-11-20 16:46:58',NULL,'2026-11-20 10:46:58','2026-11-20 10:46:58'),(8,3,'medical','pending',1,'2026-11-20 16:48:15',NULL,'2026-11-20 10:48:15','2026-11-20 10:48:15'),(9,3,'medical','fit',1,'2026-11-20 16:48:34',NULL,'2026-11-20 10:48:34','2026-11-20 10:48:34'),(10,3,'police_clearance','pending',1,'2026-11-20 16:49:20',NULL,'2026-11-20 10:49:20','2026-11-20 10:49:20'),(11,3,'police_clearance','cleared',1,'2026-11-20 16:49:20',NULL,'2026-11-20 10:49:20','2026-11-20 10:49:20');
/*!40000 ALTER TABLE `recruitment_stage_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruitments`
--

DROP TABLE IF EXISTS `recruitments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruitments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tracking_number` varchar(255) NOT NULL,
  `passport_holder_id` bigint(20) unsigned NOT NULL,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `company_id` bigint(20) unsigned DEFAULT NULL,
  `position_id` bigint(20) unsigned DEFAULT NULL,
  `expected_salary` decimal(15,2) DEFAULT NULL,
  `financial_responsible_type` varchar(255) DEFAULT NULL,
  `financial_responsible_id` bigint(20) unsigned DEFAULT NULL,
  `current_stage` varchar(255) NOT NULL DEFAULT 'registration',
  `current_status` varchar(255) NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `salary` decimal(15,2) NOT NULL DEFAULT 0.00,
  `company_service_charge` decimal(15,2) NOT NULL DEFAULT 0.00,
  `agent_charge` decimal(15,2) NOT NULL DEFAULT 0.00,
  `medical_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `training_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `visa_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `other_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `advance_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `remaining_due` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recruitments_tracking_number_unique` (`tracking_number`),
  KEY `recruitments_company_id_foreign` (`company_id`),
  KEY `recruitments_position_id_foreign` (`position_id`),
  KEY `recruitments_created_by_foreign` (`created_by`),
  KEY `recruitments_updated_by_foreign` (`updated_by`),
  KEY `recruitments_country_id_index` (`country_id`),
  KEY `recruitments_branch_id_index` (`branch_id`),
  KEY `recruitments_agent_id_index` (`agent_id`),
  KEY `recruitments_passport_holder_id_index` (`passport_holder_id`),
  KEY `recruitments_current_stage_index` (`current_stage`),
  KEY `recruitments_current_status_index` (`current_status`),
  CONSTRAINT `recruitments_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_passport_holder_id_foreign` FOREIGN KEY (`passport_holder_id`) REFERENCES `passport_holders` (`id`),
  CONSTRAINT `recruitments_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recruitments_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruitments`
--

LOCK TABLES `recruitments` WRITE;
/*!40000 ALTER TABLE `recruitments` DISABLE KEYS */;
INSERT INTO `recruitments` VALUES (3,'2026-0001-000001',1,NULL,1,9,1,7,1200.00,NULL,NULL,'police_clearance','cleared',NULL,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,1,'2026-11-20 10:40:22','2026-11-20 10:49:20',NULL);
/*!40000 ALTER TABLE `recruitments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(2,1),(2,2),(3,1),(3,2),(4,1),(4,2),(4,3),(5,1),(5,2),(6,1),(6,2),(7,1),(7,2),(8,1),(8,2),(9,1),(9,2),(10,1),(10,2),(11,1),(11,2),(12,1),(12,2),(13,1),(13,2),(14,1),(14,2),(15,1),(15,2),(16,1),(16,2),(17,1),(18,1),(18,2),(19,1),(19,2),(20,1),(20,2),(21,1),(22,1),(22,2),(23,1),(23,2),(24,1),(25,1),(25,2),(26,1),(27,1),(27,2),(28,1),(29,1),(30,1),(30,2),(30,3),(30,4),(30,6),(31,1),(31,2),(31,3),(32,1),(32,2),(32,3),(33,1),(33,2),(34,1),(34,2),(35,1),(35,2),(36,1),(36,2),(36,3),(36,4),(36,5),(36,6),(36,7),(37,1),(37,2),(37,3),(37,5),(37,6),(38,1),(38,2),(38,3),(39,1),(39,2),(40,1),(40,2),(41,1),(41,2),(42,1),(42,2),(43,1),(43,2),(43,3),(43,4),(43,5),(43,6),(43,7),(44,1),(44,2),(44,3),(44,5),(45,1),(45,2),(45,3),(45,5),(46,1),(46,2),(47,1),(47,2),(47,3),(48,1),(48,2),(48,3),(49,1),(49,2),(49,3),(50,1),(50,2),(51,1),(51,2),(52,1),(52,2),(52,3),(53,1),(53,2),(54,1),(54,2),(55,1),(55,2),(55,3),(56,1),(56,2),(56,3),(57,1),(57,2),(57,3),(58,1),(58,2),(58,3),(59,1),(59,2),(59,3),(60,1),(60,2),(61,1),(61,2),(62,1),(62,2),(62,3),(63,1),(63,2),(63,3),(64,1),(64,2),(64,3),(65,1),(65,2),(65,3),(66,1),(66,2),(66,3),(67,1),(67,2),(68,1),(68,2),(69,1),(69,2),(69,3),(70,1),(70,2),(70,3),(71,1),(71,2),(71,3),(72,1),(72,2),(72,3),(73,1),(73,2),(73,3),(74,1),(74,2),(74,3),(75,1),(75,2),(75,3),(76,1),(76,2),(76,3),(77,1),(77,2),(77,3),(78,1),(78,2),(79,1),(79,2),(80,1),(80,2),(80,3),(81,1),(81,2),(81,3),(82,1),(82,2),(82,3),(83,1),(83,2),(83,3),(84,1),(84,2),(84,3),(85,1),(85,2),(86,1),(86,2),(87,1),(87,2),(87,3),(88,1),(88,2),(88,3),(89,1),(89,2),(89,3),(90,1),(90,2),(90,3),(91,1),(91,2),(91,3),(92,1),(92,2),(92,3),(93,1),(93,2),(93,3),(94,1),(94,2),(94,3),(95,1),(95,2),(95,3),(96,1),(96,2),(96,3),(97,1),(97,2),(97,3),(98,1),(98,2),(98,3),(99,1),(99,2),(99,3),(100,1),(100,2),(101,1),(101,2),(102,1),(102,2),(102,3),(103,1),(103,2),(103,3),(104,1),(104,2),(104,3),(105,1),(105,2),(105,3),(106,1),(106,2),(106,3),(107,1),(107,2),(108,1),(108,2),(109,1),(109,2),(109,3),(110,1),(110,2),(110,3),(111,1),(111,2),(111,3),(112,1),(112,2),(112,3),(113,1),(113,2),(113,3),(114,1),(114,2),(115,1),(115,2),(116,1),(116,2),(116,3),(117,1),(117,2),(117,3),(118,1),(118,2),(118,3),(119,1),(119,2),(120,1),(120,2),(121,1),(121,2),(121,3),(122,1),(122,2),(122,3),(123,1),(123,2),(124,1),(124,2),(125,1),(125,2),(125,3),(126,1),(126,2),(126,3),(127,1),(127,2),(127,3),(128,1),(128,2),(128,3),(129,1),(129,2),(129,3),(130,1),(130,2),(131,1),(131,2),(132,1),(132,2),(132,3),(133,1),(133,2),(133,3),(134,1),(134,2),(134,3),(135,1),(135,2),(135,3),(136,1),(136,2),(137,1),(137,2),(138,1),(138,2),(138,3),(139,1),(139,2),(139,3),(140,1),(140,2),(140,3),(141,1),(141,2),(141,3),(142,1),(142,2),(143,1),(143,2),(144,1),(144,2),(144,3),(145,1),(145,2),(145,3),(146,1),(146,2),(146,3),(147,1),(147,2),(147,4),(148,1),(148,2),(148,4),(149,1),(149,2),(149,4),(150,1),(150,2),(150,4),(151,1),(151,2),(151,4),(152,1),(152,2),(152,4),(153,1),(153,2),(154,1),(154,2),(154,4),(155,1),(155,2),(156,1),(156,2),(157,1),(157,2),(158,1),(158,2),(159,1),(159,2),(159,3),(159,4),(160,1),(160,2),(160,4),(161,1),(161,2),(161,4),(162,1),(162,2),(162,4),(163,1),(163,2),(163,4),(164,1),(164,2),(164,4),(165,1),(165,2),(165,4),(166,1),(166,2),(166,4),(167,1),(167,2),(167,3),(167,4),(167,6),(167,7),(168,1),(168,2),(168,4),(169,1),(169,2),(169,4),(170,1),(170,2),(170,3),(170,4),(170,6),(171,1),(171,2),(171,4),(172,1),(172,2),(172,4),(173,1),(173,2),(174,1),(174,2),(175,1),(175,2),(176,1),(176,2),(177,1),(177,2),(178,1),(178,2),(179,1),(179,2),(180,1),(180,2),(181,1),(181,2),(182,1),(182,2),(183,1),(183,2),(184,1),(184,2),(185,1),(185,2),(186,1),(186,2),(187,1),(187,2),(188,1),(188,2),(189,1),(189,2),(190,1),(190,2),(191,1),(191,2),(192,1),(192,2),(193,1),(193,2),(194,1),(194,2),(195,1),(195,2),(196,1),(196,2),(197,1),(197,2),(198,1),(198,2),(199,1),(199,2),(200,1),(200,2),(201,1),(201,2),(202,1),(202,2),(203,1),(203,2),(204,1),(204,2),(205,1),(205,2),(206,1),(206,2),(207,1),(207,2),(208,1),(208,2),(209,1),(209,2),(209,4),(210,1),(210,2),(211,1),(211,2),(212,1),(212,2),(212,4),(213,1),(213,2),(213,4),(214,1),(214,2),(215,1),(215,2),(216,1),(216,2),(217,1),(217,2),(217,3),(217,5),(218,1),(218,2),(218,3),(218,5),(219,1),(219,2),(219,3),(220,1),(220,2),(220,3),(221,1),(221,2),(222,1),(223,1),(224,1),(224,2),(224,3),(224,4),(224,5),(224,6),(224,7),(225,1),(225,2),(225,3),(225,4),(225,6),(225,7),(226,1),(226,2),(227,1),(227,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','web','2026-11-20 10:15:13','2026-11-20 10:15:13'),(2,'Admin','web','2026-11-20 10:15:13','2026-11-20 10:15:13'),(3,'Branch Manager','web','2026-11-20 10:15:14','2026-11-20 10:15:14'),(4,'Accounts Staff','web','2026-11-20 10:15:14','2026-11-20 10:15:14'),(5,'General Staff','web','2026-11-20 10:15:14','2026-11-20 10:15:14'),(6,'Agent','web','2026-11-20 10:15:15','2026-11-20 10:15:15'),(7,'Passport Holder','web','2026-11-20 10:15:15','2026-11-20 10:15:15');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_structures`
--

DROP TABLE IF EXISTS `salary_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_structures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `basic` decimal(15,2) NOT NULL,
  `allowances` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`allowances`)),
  `deductions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`deductions`)),
  `effective_from` date DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_structures_created_by_foreign` (`created_by`),
  KEY `salary_structures_updated_by_foreign` (`updated_by`),
  KEY `salary_structures_employee_id_index` (`employee_id`),
  KEY `salary_structures_status_index` (`status`),
  CONSTRAINT `salary_structures_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_structures_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_structures_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_structures`
--

LOCK TABLES `salary_structures` WRITE;
/*!40000 ALTER TABLE `salary_structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selection_grades`
--

DROP TABLE IF EXISTS `selection_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selection_grades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `selection_id` bigint(20) unsigned NOT NULL,
  `grading_criterion_id` bigint(20) unsigned NOT NULL,
  `score` decimal(15,2) NOT NULL DEFAULT 0.00,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selection_grades_selection_id_index` (`selection_id`),
  KEY `selection_grades_grading_criterion_id_index` (`grading_criterion_id`),
  CONSTRAINT `selection_grades_grading_criterion_id_foreign` FOREIGN KEY (`grading_criterion_id`) REFERENCES `grading_criteria` (`id`) ON DELETE CASCADE,
  CONSTRAINT `selection_grades_selection_id_foreign` FOREIGN KEY (`selection_id`) REFERENCES `selections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selection_grades`
--

LOCK TABLES `selection_grades` WRITE;
/*!40000 ALTER TABLE `selection_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `selection_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `selections`
--

DROP TABLE IF EXISTS `selections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `grade` varchar(255) DEFAULT NULL,
  `grading_criteria_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`grading_criteria_snapshot`)),
  `remarks` text DEFAULT NULL,
  `decided_by` bigint(20) unsigned DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `status` enum('pending','approved','rejected','returned','cancelled') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selections_decided_by_foreign` (`decided_by`),
  KEY `selections_created_by_foreign` (`created_by`),
  KEY `selections_updated_by_foreign` (`updated_by`),
  KEY `selections_recruitment_id_index` (`recruitment_id`),
  KEY `selections_status_index` (`status`),
  CONSTRAINT `selections_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `selections_decided_by_foreign` FOREIGN KEY (`decided_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `selections_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `selections_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `selections`
--

LOCK TABLES `selections` WRITE;
/*!40000 ALTER TABLE `selections` DISABLE KEYS */;
INSERT INTO `selections` VALUES (1,3,'A+',NULL,NULL,NULL,'2026-11-20 00:00:00','approved',NULL,NULL,'2026-11-20 10:44:54','2026-11-20 10:45:09',NULL);
/*!40000 ALTER TABLE `selections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_group_index` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'currency','BDT','general','2026-11-20 10:15:15','2026-11-20 10:15:15'),(2,'timezone','Asia/Dhaka','general','2026-11-20 10:15:15','2026-11-20 10:15:15'),(3,'language','en','general','2026-11-20 10:15:15','2026-11-20 10:15:15'),(4,'date_format','d-m-Y','general','2026-11-20 10:15:15','2026-11-20 10:15:15'),(5,'theme','light','general','2026-11-20 10:15:15','2026-11-20 10:15:15'),(6,'software_name','Manpower Recruitment & Overseas Employment ERP','branding','2026-11-20 10:15:15','2026-11-20 10:15:15'),(7,'software_short_name','Manpower ERP','branding','2026-11-20 10:15:15','2026-11-20 10:15:15'),(8,'primary_color','#0d6efd','branding','2026-11-20 10:15:15','2026-11-20 10:15:15'),(9,'secondary_color','#6c757d','branding','2026-11-20 10:15:15','2026-11-20 10:15:15'),(10,'invoice_prefix','INV','finance','2026-11-20 10:15:15','2026-11-20 10:15:15'),(11,'voucher_prefix','VCH','finance','2026-11-20 10:15:15','2026-11-20 10:15:15'),(12,'tracking_prefix','TRK','recruitment','2026-11-20 10:15:15','2026-11-20 10:15:15'),(13,'login_attempts','5','security','2026-11-20 10:15:15','2026-11-20 10:15:15'),(14,'session_lifetime','120','security','2026-11-20 10:15:15','2026-11-20 10:15:15');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracking_numbers`
--

DROP TABLE IF EXISTS `tracking_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracking_numbers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tracking_number` varchar(255) NOT NULL,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `year` int(11) NOT NULL,
  `sequence` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_numbers_tracking_number_unique` (`tracking_number`),
  KEY `tracking_numbers_recruitment_id_foreign` (`recruitment_id`),
  KEY `tracking_numbers_branch_id_index` (`branch_id`),
  KEY `tracking_numbers_year_index` (`year`),
  CONSTRAINT `tracking_numbers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tracking_numbers_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracking_numbers`
--

LOCK TABLES `tracking_numbers` WRITE;
/*!40000 ALTER TABLE `tracking_numbers` DISABLE KEYS */;
INSERT INTO `tracking_numbers` VALUES (3,'2026-0001-000001',3,1,2026,1,'2026-11-20 10:40:22','2026-11-20 10:40:22');
/*!40000 ALTER TABLE `tracking_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_centres`
--

DROP TABLE IF EXISTS `training_centres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_centres` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `training_centres_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_centres`
--

LOCK TABLES `training_centres` WRITE;
/*!40000 ALTER TABLE `training_centres` DISABLE KEYS */;
INSERT INTO `training_centres` VALUES (1,'polpol.p',NULL,NULL,NULL,'active','2026-11-20 10:52:01','2026-11-20 10:52:01');
/*!40000 ALTER TABLE `training_centres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_courses`
--

DROP TABLE IF EXISTS `training_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_courses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `training_centre_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `duration_days` int(11) DEFAULT NULL,
  `fee` decimal(15,2) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `training_courses_status_index` (`status`),
  KEY `training_courses_training_centre_id_index` (`training_centre_id`),
  CONSTRAINT `training_courses_training_centre_id_foreign` FOREIGN KEY (`training_centre_id`) REFERENCES `training_centres` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_courses`
--

LOCK TABLES `training_courses` WRITE;
/*!40000 ALTER TABLE `training_courses` DISABLE KEYS */;
INSERT INTO `training_courses` VALUES (1,1,'moik,po',30,300.00,'active','2026-11-20 10:52:39','2026-11-20 10:52:39');
/*!40000 ALTER TABLE `training_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainings`
--

DROP TABLE IF EXISTS `trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `training_centre_id` bigint(20) unsigned DEFAULT NULL,
  `course_id` bigint(20) unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `attendance_percentage` decimal(15,2) DEFAULT NULL,
  `result` enum('pending','passed','failed','cancelled') NOT NULL DEFAULT 'pending',
  `certificate_path` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trainings_training_centre_id_foreign` (`training_centre_id`),
  KEY `trainings_course_id_foreign` (`course_id`),
  KEY `trainings_created_by_foreign` (`created_by`),
  KEY `trainings_updated_by_foreign` (`updated_by`),
  KEY `trainings_recruitment_id_index` (`recruitment_id`),
  KEY `trainings_result_index` (`result`),
  CONSTRAINT `trainings_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trainings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trainings_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `trainings_training_centre_id_foreign` FOREIGN KEY (`training_centre_id`) REFERENCES `training_centres` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trainings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainings`
--

LOCK TABLES `trainings` WRITE;
/*!40000 ALTER TABLE `trainings` DISABLE KEYS */;
/*!40000 ALTER TABLE `trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_agencies`
--

DROP TABLE IF EXISTS `travel_agencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_agencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_agencies_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_agencies`
--

LOCK TABLES `travel_agencies` WRITE;
/*!40000 ALTER TABLE `travel_agencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_agencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_branch`
--

DROP TABLE IF EXISTS `user_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_branch` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_branch_user_id_index` (`user_id`),
  KEY `user_branch_branch_id_index` (`branch_id`),
  CONSTRAINT `user_branch_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_branch_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_branch`
--

LOCK TABLES `user_branch` WRITE;
/*!40000 ALTER TABLE `user_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_country`
--

DROP TABLE IF EXISTS `user_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_country` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `country_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_country_user_id_index` (`user_id`),
  KEY `user_country_country_id_index` (`country_id`),
  CONSTRAINT `user_country_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_country_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_country`
--

LOCK TABLES `user_country` WRITE;
/*!40000 ALTER TABLE `user_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `last_login_at` datetime DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_status_index` (`status`),
  KEY `users_branch_id_index` (`branch_id`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin','manpoweradmin@gmail.com',NULL,'$2y$12$dW0crnawNSs2acopvzXD2uhzqNFrPdlGOuh/8Bi1oLr4xssGAz87C',NULL,NULL,'active','2026-11-20 16:17:06',1,NULL,'2026-11-20 10:15:16','2026-11-20 10:17:06'),(2,'New agent test','razibhasan2403@gmail.com',NULL,'$2y$12$0IIqOLNQ25S6iogO4YQ5U.x8dAMv0kmBkGQpBpWxGoXicrFvIY7we','01912549957',1,'active',NULL,0,NULL,'2026-11-20 10:31:44','2026-11-20 10:31:44'),(3,'MD ANOWAR HOSEN','razibhasan23@gmail.com',NULL,'$2y$12$uRx0HNM7vfZ/6mUyr5m1YeNor5r1YvPSL9LXS2/RXOcVq7JDaml..','+8801342624634',1,'active',NULL,0,NULL,'2026-11-20 10:36:55','2026-11-20 10:36:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visa_lots`
--

DROP TABLE IF EXISTS `visa_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visa_lots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lot_number` varchar(255) NOT NULL,
  `country_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('open','submitted','closed','cancelled') NOT NULL DEFAULT 'open',
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `visa_lots_lot_number_unique` (`lot_number`),
  KEY `visa_lots_created_by_foreign` (`created_by`),
  KEY `visa_lots_updated_by_foreign` (`updated_by`),
  KEY `visa_lots_status_index` (`status`),
  KEY `visa_lots_country_id_index` (`country_id`),
  CONSTRAINT `visa_lots_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visa_lots_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visa_lots_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visa_lots`
--

LOCK TABLES `visa_lots` WRITE;
/*!40000 ALTER TABLE `visa_lots` DISABLE KEYS */;
/*!40000 ALTER TABLE `visa_lots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visa_returns`
--

DROP TABLE IF EXISTS `visa_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visa_returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visa_id` bigint(20) unsigned NOT NULL,
  `return_date` date DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `return_type` enum('handover','courier','agent_collection','other') NOT NULL DEFAULT 'handover',
  `responsible_person` varchar(255) DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('pending','returned','cancelled') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visa_returns_created_by_foreign` (`created_by`),
  KEY `visa_returns_updated_by_foreign` (`updated_by`),
  KEY `visa_returns_visa_id_index` (`visa_id`),
  KEY `visa_returns_status_index` (`status`),
  CONSTRAINT `visa_returns_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visa_returns_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visa_returns_visa_id_foreign` FOREIGN KEY (`visa_id`) REFERENCES `visas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visa_returns`
--

LOCK TABLES `visa_returns` WRITE;
/*!40000 ALTER TABLE `visa_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `visa_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visas`
--

DROP TABLE IF EXISTS `visas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruitment_id` bigint(20) unsigned NOT NULL,
  `visa_lot_id` bigint(20) unsigned DEFAULT NULL,
  `mofa_status` enum('pending','submitted','approved','rejected','returned') NOT NULL DEFAULT 'pending',
  `submission_date` date DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `status` enum('pending','submitted','approved','rejected','returned','cancelled') NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visas_created_by_foreign` (`created_by`),
  KEY `visas_updated_by_foreign` (`updated_by`),
  KEY `visas_recruitment_id_index` (`recruitment_id`),
  KEY `visas_status_index` (`status`),
  KEY `visas_visa_lot_id_index` (`visa_lot_id`),
  CONSTRAINT `visas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visas_recruitment_id_foreign` FOREIGN KEY (`recruitment_id`) REFERENCES `recruitments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `visas_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visas_visa_lot_id_foreign` FOREIGN KEY (`visa_lot_id`) REFERENCES `visa_lots` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visas`
--

LOCK TABLES `visas` WRITE;
/*!40000 ALTER TABLE `visas` DISABLE KEYS */;
/*!40000 ALTER TABLE `visas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_passes`
--

DROP TABLE IF EXISTS `visitor_passes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_passes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visitor_id` bigint(20) unsigned NOT NULL,
  `pass_number` varchar(255) NOT NULL,
  `issued_at` datetime DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `status` enum('issued','returned','lost') NOT NULL DEFAULT 'issued',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `visitor_passes_pass_number_unique` (`pass_number`),
  KEY `visitor_passes_visitor_id_index` (`visitor_id`),
  KEY `visitor_passes_status_index` (`status`),
  CONSTRAINT `visitor_passes_visitor_id_foreign` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_passes`
--

LOCK TABLES `visitor_passes` WRITE;
/*!40000 ALTER TABLE `visitor_passes` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitor_passes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitors`
--

DROP TABLE IF EXISTS `visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `person_to_meet` varchar(255) DEFAULT NULL,
  `entry_time` datetime DEFAULT NULL,
  `exit_time` datetime DEFAULT NULL,
  `pass_number` varchar(255) DEFAULT NULL,
  `status` enum('inside','left','cancelled') NOT NULL DEFAULT 'inside',
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visitors_created_by_foreign` (`created_by`),
  KEY `visitors_updated_by_foreign` (`updated_by`),
  KEY `visitors_status_index` (`status`),
  KEY `visitors_branch_id_index` (`branch_id`),
  KEY `visitors_entry_time_index` (`entry_time`),
  CONSTRAINT `visitors_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visitors_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `visitors_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitors`
--

LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `voucher_number` varchar(255) NOT NULL,
  `voucher_type` enum('payment','receipt','journal','contra') NOT NULL DEFAULT 'journal',
  `voucher_date` date NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `total_debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('draft','posted','reversed','cancelled') NOT NULL DEFAULT 'draft',
  `posted_by` bigint(20) unsigned DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `reversed_by` bigint(20) unsigned DEFAULT NULL,
  `reversal_voucher_id` bigint(20) unsigned DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vouchers_voucher_number_unique` (`voucher_number`),
  KEY `vouchers_posted_by_foreign` (`posted_by`),
  KEY `vouchers_reversed_by_foreign` (`reversed_by`),
  KEY `vouchers_reversal_voucher_id_foreign` (`reversal_voucher_id`),
  KEY `vouchers_created_by_foreign` (`created_by`),
  KEY `vouchers_updated_by_foreign` (`updated_by`),
  KEY `vouchers_status_index` (`status`),
  KEY `vouchers_branch_id_index` (`branch_id`),
  KEY `vouchers_voucher_type_index` (`voucher_type`),
  KEY `vouchers_voucher_date_index` (`voucher_date`),
  CONSTRAINT `vouchers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_posted_by_foreign` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_reversal_voucher_id_foreign` FOREIGN KEY (`reversal_voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_reversed_by_foreign` FOREIGN KEY (`reversed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vouchers_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_permits`
--

DROP TABLE IF EXISTS `work_permits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_permits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visa_id` bigint(20) unsigned NOT NULL,
  `permit_number` varchar(255) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `work_permits_created_by_foreign` (`created_by`),
  KEY `work_permits_updated_by_foreign` (`updated_by`),
  KEY `work_permits_visa_id_index` (`visa_id`),
  CONSTRAINT `work_permits_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `work_permits_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `work_permits_visa_id_foreign` FOREIGN KEY (`visa_id`) REFERENCES `visas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_permits`
--

LOCK TABLES `work_permits` WRITE;
/*!40000 ALTER TABLE `work_permits` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_permits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'manpower_erp_new'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-20 17:05:47
